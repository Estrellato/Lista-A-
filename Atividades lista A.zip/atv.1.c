#include<stdio.h>
#include<stdlib.h>

int main (void)
{
	char nome[100];
	printf("Digite seu nome: \n");
	scanf("%s", &nome);
	printf("\n%s", nome);
	system("\n pause")
}
