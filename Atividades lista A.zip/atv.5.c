#include <stdio.h>
#include <stdlib.h>

void main()
{
	int n;
	printf("Digite o numero: ");
	scanf("%d", &n);
	printf("Numero digitado: %d", n);
}
