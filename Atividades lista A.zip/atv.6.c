#include <stdio.h>
#include <stdlib.h>

void main()
{
	float n, n2;
	
	printf("Digite o numero 1: ");
	scanf("%f",&n);
	printf("Digite o numero 2: ");
	scanf("%f",&n2);
	printf("Numeros reais: %f %f", n, n2);
}
