#include <stdio.h>
#include <stdlib.h>

void main()
{
	float resultado;
	resultado = (5 + 8 + 12) / 3;
	printf("Resultado: %f", resultado);
}
