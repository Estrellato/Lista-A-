#include <stdio.h>
#include <stdlib.h>

void main()
{
	float n;
	printf("Digite o numero: ");
	scanf("%f",&n);
	printf("Antessecor: %f e Sucessor: %f", n-1, n+1);
}
