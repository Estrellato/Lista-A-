#include <stdio.h>
#include <stdlib.h>

void main ()
{
	int resultado;
	resultado = 30 * 27;
	printf("Resuktado: %d", resultado);
}
